﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Assignment_SWD
{
    public class PersonModel // Persons aren't very interesting and only contain a name and an age
    {
            public string Age { get; set; }
            public string Name { get; set; }
    }
}
