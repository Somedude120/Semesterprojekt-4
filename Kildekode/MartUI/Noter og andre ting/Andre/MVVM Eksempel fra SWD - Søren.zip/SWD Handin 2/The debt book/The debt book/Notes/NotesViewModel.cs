﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Mvvm;

namespace GUI_Assignment_SWD
{
    public class NotesViewModel : BindableBase, IPageViewModel
    {
        public string Name //Contains a reference to Notes
        {
            get { return "Notes"; }
        }
    }
}
