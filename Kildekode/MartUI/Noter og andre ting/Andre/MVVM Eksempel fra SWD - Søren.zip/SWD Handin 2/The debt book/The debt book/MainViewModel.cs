﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Prism.Commands;
using Prism.Mvvm;

namespace GUI_Assignment_SWD
{
    public class MainViewModel : BindableBase
    {
        private ICommand _changePage;
        private IPageViewModel _currentPage;
        private List<IPageViewModel> _pageList;

        public MainViewModel()  //Creates and adds a single object of each viewmodel into the list of viewmodels
        {
            PageList.Add(new PersonViewModel());
            PageList.Add(new NotesViewModel());

            CurrentPage = PageList[0];
        }

        public List<IPageViewModel> PageList //Contains all the viewmodels
        {
            get
            {
                if (_pageList == null)
                {
                    _pageList = new List<IPageViewModel>();
                }
                   
                return _pageList;
            }
        }

        public IPageViewModel CurrentPage //Holds information about the current page
        {
            get { return _currentPage; }
            set
            {
                if (_currentPage != value)
                {
                    _currentPage = value;
                    RaisePropertyChanged("CurrentPage");
                }
            }
        }

        public ICommand ChangePage //Changes page
        {
            get
            {
                if (_changePage == null)
                {
                    _changePage = new DelegateCommand<IPageViewModel>(p => ChangeViewModel((IPageViewModel)p),
                        p => p is IPageViewModel);
                }
                return _changePage;
            }
        }

        private void ChangeViewModel(IPageViewModel viewModel) //Changes viewmodel
        {
            if(!PageList.Contains(viewModel))
                PageList.Add(viewModel);

            CurrentPage = PageList.FirstOrDefault(vm => vm == viewModel);
        }
    }
}
