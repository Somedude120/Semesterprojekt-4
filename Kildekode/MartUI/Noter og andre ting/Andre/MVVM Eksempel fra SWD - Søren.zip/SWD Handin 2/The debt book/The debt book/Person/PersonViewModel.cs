﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Prism.Commands;
using Prism.Mvvm;

namespace GUI_Assignment_SWD
{
    public class PersonViewModel : BindableBase, IPageViewModel
    {
        private List<PersonModel> _personList;
        private PersonModel _currentPerson;
        private ICommand _changePerson;

        public PersonViewModel() //Hardcoded buttons for persons, could be added dynamically
        {
            var Alex = new PersonModel();
            Alex.Name = "Alex";
            Alex.Age = "12";
            var Fred = new PersonModel();
            Fred.Name = "Fred";
            Fred.Age = "69";

            PersonList.Add(Alex);
            PersonList.Add(Fred);

            CurrentPerson = PersonList[0];
        }

        public string Name //This viewmodels name and reference
        {
            get { return "Person"; }
        }

        public List<PersonModel> PersonList //A list of persons
        {
            get
            {
                if (_personList == null)
                {
                    _personList = new List<PersonModel>();
                }
                return _personList;
            }
        }

        public PersonModel CurrentPerson //Refers to the current person
        {
            get { return _currentPerson; }
            set
            {
                if (_currentPerson != value)
                {
                    _currentPerson = value;
                    RaisePropertyChanged("CurrentPerson");
                }
            }
        }

        public ICommand ChangePerson //Changes person
        {
            get
            {
                if (_changePerson == null)
                {
                    _changePerson = new DelegateCommand<PersonModel>(p => ChangePersonViewModel((PersonModel)p),
                        p => p is PersonModel);
                }
                return _changePerson;
            }
        }

        private void ChangePersonViewModel(PersonModel person) //Changes personviewmodel - Bad name
        {
            if (!PersonList.Contains(person))
                PersonList.Add(person);

            CurrentPerson = PersonList.FirstOrDefault(p => p == person);
        }
    }
}
